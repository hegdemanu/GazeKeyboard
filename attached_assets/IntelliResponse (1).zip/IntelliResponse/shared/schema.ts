import { pgTable, text, serial, integer, boolean, timestamp, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User table for storing user preferences and data
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email"),
  isFreelancer: boolean("is_freelancer").default(false),
  createdAt: timestamp("created_at").defaultNow(),
});

// User input history for analytics and improving predictions
export const inputHistory = pgTable("input_history", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  inputText: text("input_text").notNull(),
  timestamp: text("timestamp").notNull(), // ISO string timestamp
});

// Custom dictionaries for word prediction
export const dictionaries = pgTable("dictionaries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id),
  name: text("name").notNull(),
  isDefault: boolean("is_default").default(false),
});

// Dictionary words for prediction
export const dictionaryWords = pgTable("dictionary_words", {
  id: serial("id").primaryKey(),
  dictionaryId: integer("dictionary_id").references(() => dictionaries.id),
  word: text("word").notNull(),
  weight: integer("weight").default(1),
});

// Customer inquiries for freelancers
export const customerInquiries = pgTable("customer_inquiries", {
  id: serial("id").primaryKey(),
  freelancerId: integer("freelancer_id").references(() => users.id),
  question: text("question").notNull(),
  category: text("category").notNull(),
  frequency: integer("frequency").default(1),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Saved responses for common inquiries
export const savedResponses = pgTable("saved_responses", {
  id: serial("id").primaryKey(),
  freelancerId: integer("freelancer_id").references(() => users.id),
  inquiryId: integer("inquiry_id").references(() => customerInquiries.id),
  responseText: text("response_text").notNull(),
  isDefault: boolean("is_default").default(false),
  effectiveness: integer("effectiveness").default(50), // 0-100 scale
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// User feedback on responses
export const responseFeedback = pgTable("response_feedback", {
  id: serial("id").primaryKey(),
  responseId: integer("response_id").references(() => savedResponses.id),
  userId: integer("user_id").references(() => users.id),
  rating: integer("rating"), // 1-5 scale
  comment: text("comment"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Contextual tags for better categorization
export const contextualTags = pgTable("contextual_tags", {
  id: serial("id").primaryKey(),
  freelancerId: integer("freelancer_id").references(() => users.id),
  name: text("name").notNull(),
  description: text("description"),
});

// Many-to-many relationship between inquiries and tags
export const inquiryTags = pgTable("inquiry_tags", {
  id: serial("id").primaryKey(),
  inquiryId: integer("inquiry_id").references(() => customerInquiries.id),
  tagId: integer("tag_id").references(() => contextualTags.id),
});

// Machine learning models for response suggestions
export const mlModels = pgTable("ml_models", {
  id: serial("id").primaryKey(),
  freelancerId: integer("freelancer_id").references(() => users.id),
  modelType: text("model_type").notNull(),
  parameters: json("parameters"),
  accuracy: integer("accuracy").default(0),
  lastTrained: timestamp("last_trained").defaultNow(),
});

// Insert schemas for each model
export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  isFreelancer: true,
});

export const insertInputHistorySchema = createInsertSchema(inputHistory).pick({
  userId: true,
  inputText: true,
  timestamp: true,
});

export const insertDictionarySchema = createInsertSchema(dictionaries).pick({
  userId: true,
  name: true,
  isDefault: true,
});

export const insertDictionaryWordSchema = createInsertSchema(dictionaryWords).pick({
  dictionaryId: true,
  word: true,
  weight: true,
});

export const insertCustomerInquirySchema = createInsertSchema(customerInquiries).pick({
  freelancerId: true,
  question: true,
  category: true,
  frequency: true,
});

export const insertSavedResponseSchema = createInsertSchema(savedResponses).pick({
  freelancerId: true,
  inquiryId: true,
  responseText: true,
  isDefault: true,
  effectiveness: true,
});

export const insertResponseFeedbackSchema = createInsertSchema(responseFeedback).pick({
  responseId: true,
  userId: true,
  rating: true,
  comment: true,
});

export const insertContextualTagSchema = createInsertSchema(contextualTags).pick({
  freelancerId: true,
  name: true,
  description: true,
});

export const insertInquiryTagSchema = createInsertSchema(inquiryTags).pick({
  inquiryId: true,
  tagId: true,
});

export const insertMlModelSchema = createInsertSchema(mlModels).pick({
  freelancerId: true,
  modelType: true,
  parameters: true,
  accuracy: true,
});

// Types for each model
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertInputHistory = z.infer<typeof insertInputHistorySchema>;
export type InputHistory = typeof inputHistory.$inferSelect;

export type InsertDictionary = z.infer<typeof insertDictionarySchema>;
export type Dictionary = typeof dictionaries.$inferSelect;

export type InsertDictionaryWord = z.infer<typeof insertDictionaryWordSchema>;
export type DictionaryWord = typeof dictionaryWords.$inferSelect;

export type InsertCustomerInquiry = z.infer<typeof insertCustomerInquirySchema>;
export type CustomerInquiry = typeof customerInquiries.$inferSelect;

export type InsertSavedResponse = z.infer<typeof insertSavedResponseSchema>;
export type SavedResponse = typeof savedResponses.$inferSelect;

export type InsertResponseFeedback = z.infer<typeof insertResponseFeedbackSchema>;
export type ResponseFeedback = typeof responseFeedback.$inferSelect;

export type InsertContextualTag = z.infer<typeof insertContextualTagSchema>;
export type ContextualTag = typeof contextualTags.$inferSelect;

export type InsertInquiryTag = z.infer<typeof insertInquiryTagSchema>;
export type InquiryTag = typeof inquiryTags.$inferSelect;

export type InsertMlModel = z.infer<typeof insertMlModelSchema>;
export type MlModel = typeof mlModels.$inferSelect;
