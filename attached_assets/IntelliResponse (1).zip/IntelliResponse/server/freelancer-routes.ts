import type { Express } from "express";
import { storage } from "./storage";
import { 
  insertCustomerInquirySchema, 
  insertSavedResponseSchema,
  insertResponseFeedbackSchema,
  insertContextualTagSchema,
  insertInquiryTagSchema,
  insertMlModelSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerFreelancerRoutes(app: Express): Promise<void> {
  // Customer Inquiries API
  
  // Get all inquiries for a freelancer
  app.get("/api/freelancer/:freelancerId/inquiries", async (req, res) => {
    try {
      const freelancerId = parseInt(req.params.freelancerId);
      if (isNaN(freelancerId)) {
        return res.status(400).json({ message: "Invalid freelancer ID" });
      }
      
      const inquiries = await storage.getCustomerInquiriesByFreelancerId(freelancerId);
      return res.json(inquiries);
    } catch (error) {
      console.error("Error fetching inquiries:", error);
      return res.status(500).json({ message: "Failed to fetch inquiries" });
    }
  });

  // Get inquiries by category
  app.get("/api/freelancer/:freelancerId/inquiries/category/:category", async (req, res) => {
    try {
      const freelancerId = parseInt(req.params.freelancerId);
      if (isNaN(freelancerId)) {
        return res.status(400).json({ message: "Invalid freelancer ID" });
      }
      
      const { category } = req.params;
      const inquiries = await storage.getCustomerInquiriesByCategory(freelancerId, category);
      return res.json(inquiries);
    } catch (error) {
      console.error("Error fetching inquiries by category:", error);
      return res.status(500).json({ message: "Failed to fetch inquiries by category" });
    }
  });

  // Create a new inquiry
  app.post("/api/inquiry", async (req, res) => {
    try {
      const validatedData = insertCustomerInquirySchema.parse(req.body);
      const inquiry = await storage.createCustomerInquiry(validatedData);
      return res.status(201).json(inquiry);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid inquiry data", errors: error.errors });
      }
      console.error("Error creating inquiry:", error);
      return res.status(500).json({ message: "Failed to create inquiry" });
    }
  });

  // Update inquiry frequency (for tracking popularity)
  app.patch("/api/inquiry/:id/frequency", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid inquiry ID" });
      }
      
      const { frequency } = req.body;
      if (typeof frequency !== 'number' || frequency < 0) {
        return res.status(400).json({ message: "Invalid frequency value" });
      }
      
      const updatedInquiry = await storage.updateCustomerInquiryFrequency(id, frequency);
      if (!updatedInquiry) {
        return res.status(404).json({ message: "Inquiry not found" });
      }
      
      return res.json(updatedInquiry);
    } catch (error) {
      console.error("Error updating inquiry frequency:", error);
      return res.status(500).json({ message: "Failed to update inquiry frequency" });
    }
  });

  // Saved Responses API
  
  // Get all responses for a freelancer
  app.get("/api/freelancer/:freelancerId/responses", async (req, res) => {
    try {
      const freelancerId = parseInt(req.params.freelancerId);
      if (isNaN(freelancerId)) {
        return res.status(400).json({ message: "Invalid freelancer ID" });
      }
      
      const responses = await storage.getSavedResponsesByFreelancerId(freelancerId);
      return res.json(responses);
    } catch (error) {
      console.error("Error fetching responses:", error);
      return res.status(500).json({ message: "Failed to fetch responses" });
    }
  });

  // Get responses for a specific inquiry
  app.get("/api/inquiry/:inquiryId/responses", async (req, res) => {
    try {
      const inquiryId = parseInt(req.params.inquiryId);
      if (isNaN(inquiryId)) {
        return res.status(400).json({ message: "Invalid inquiry ID" });
      }
      
      const responses = await storage.getSavedResponsesByInquiryId(inquiryId);
      return res.json(responses);
    } catch (error) {
      console.error("Error fetching responses for inquiry:", error);
      return res.status(500).json({ message: "Failed to fetch responses for inquiry" });
    }
  });

  // Get default response for an inquiry
  app.get("/api/inquiry/:inquiryId/default-response", async (req, res) => {
    try {
      const inquiryId = parseInt(req.params.inquiryId);
      if (isNaN(inquiryId)) {
        return res.status(400).json({ message: "Invalid inquiry ID" });
      }
      
      const defaultResponse = await storage.getDefaultSavedResponseForInquiry(inquiryId);
      if (!defaultResponse) {
        return res.status(404).json({ message: "No default response found for this inquiry" });
      }
      
      return res.json(defaultResponse);
    } catch (error) {
      console.error("Error fetching default response:", error);
      return res.status(500).json({ message: "Failed to fetch default response" });
    }
  });

  // Create a new saved response
  app.post("/api/response", async (req, res) => {
    try {
      const validatedData = insertSavedResponseSchema.parse(req.body);
      const response = await storage.createSavedResponse(validatedData);
      return res.status(201).json(response);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid response data", errors: error.errors });
      }
      console.error("Error creating response:", error);
      return res.status(500).json({ message: "Failed to create response" });
    }
  });

  // Update response effectiveness
  app.patch("/api/response/:id/effectiveness", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid response ID" });
      }
      
      const { effectiveness } = req.body;
      if (typeof effectiveness !== 'number' || effectiveness < 0 || effectiveness > 100) {
        return res.status(400).json({ message: "Invalid effectiveness value (0-100)" });
      }
      
      const updatedResponse = await storage.updateSavedResponseEffectiveness(id, effectiveness);
      if (!updatedResponse) {
        return res.status(404).json({ message: "Response not found" });
      }
      
      return res.json(updatedResponse);
    } catch (error) {
      console.error("Error updating response effectiveness:", error);
      return res.status(500).json({ message: "Failed to update response effectiveness" });
    }
  });

  // Response Feedback API
  
  // Create new feedback for a response
  app.post("/api/feedback", async (req, res) => {
    try {
      const validatedData = insertResponseFeedbackSchema.parse(req.body);
      const feedback = await storage.createResponseFeedback(validatedData);
      return res.status(201).json(feedback);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid feedback data", errors: error.errors });
      }
      console.error("Error creating feedback:", error);
      return res.status(500).json({ message: "Failed to create feedback" });
    }
  });

  // Get all feedback for a response
  app.get("/api/response/:responseId/feedback", async (req, res) => {
    try {
      const responseId = parseInt(req.params.responseId);
      if (isNaN(responseId)) {
        return res.status(400).json({ message: "Invalid response ID" });
      }
      
      const feedback = await storage.getResponseFeedbackByResponseId(responseId);
      return res.json(feedback);
    } catch (error) {
      console.error("Error fetching feedback:", error);
      return res.status(500).json({ message: "Failed to fetch feedback" });
    }
  });

  // Contextual Tags API
  
  // Create a new tag
  app.post("/api/tag", async (req, res) => {
    try {
      const validatedData = insertContextualTagSchema.parse(req.body);
      const tag = await storage.createContextualTag(validatedData);
      return res.status(201).json(tag);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid tag data", errors: error.errors });
      }
      console.error("Error creating tag:", error);
      return res.status(500).json({ message: "Failed to create tag" });
    }
  });

  // Get all tags for a freelancer
  app.get("/api/freelancer/:freelancerId/tags", async (req, res) => {
    try {
      const freelancerId = parseInt(req.params.freelancerId);
      if (isNaN(freelancerId)) {
        return res.status(400).json({ message: "Invalid freelancer ID" });
      }
      
      const tags = await storage.getContextualTagsByFreelancerId(freelancerId);
      return res.json(tags);
    } catch (error) {
      console.error("Error fetching tags:", error);
      return res.status(500).json({ message: "Failed to fetch tags" });
    }
  });

  // Inquiry Tags API
  
  // Associate a tag with an inquiry
  app.post("/api/inquiry-tag", async (req, res) => {
    try {
      const validatedData = insertInquiryTagSchema.parse(req.body);
      const inquiryTag = await storage.createInquiryTag(validatedData);
      return res.status(201).json(inquiryTag);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid inquiry-tag data", errors: error.errors });
      }
      console.error("Error creating inquiry-tag:", error);
      return res.status(500).json({ message: "Failed to create inquiry-tag" });
    }
  });

  // Get all tags for an inquiry
  app.get("/api/inquiry/:inquiryId/tags", async (req, res) => {
    try {
      const inquiryId = parseInt(req.params.inquiryId);
      if (isNaN(inquiryId)) {
        return res.status(400).json({ message: "Invalid inquiry ID" });
      }
      
      const inquiryTags = await storage.getInquiryTagsByInquiryId(inquiryId);
      return res.json(inquiryTags);
    } catch (error) {
      console.error("Error fetching inquiry tags:", error);
      return res.status(500).json({ message: "Failed to fetch inquiry tags" });
    }
  });

  // ML Models API
  
  // Create a new ML model
  app.post("/api/ml-model", async (req, res) => {
    try {
      const validatedData = insertMlModelSchema.parse(req.body);
      const model = await storage.createMlModel(validatedData);
      return res.status(201).json(model);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid ML model data", errors: error.errors });
      }
      console.error("Error creating ML model:", error);
      return res.status(500).json({ message: "Failed to create ML model" });
    }
  });

  // Get all ML models for a freelancer
  app.get("/api/freelancer/:freelancerId/ml-models", async (req, res) => {
    try {
      const freelancerId = parseInt(req.params.freelancerId);
      if (isNaN(freelancerId)) {
        return res.status(400).json({ message: "Invalid freelancer ID" });
      }
      
      const models = await storage.getMlModelsByFreelancerId(freelancerId);
      return res.json(models);
    } catch (error) {
      console.error("Error fetching ML models:", error);
      return res.status(500).json({ message: "Failed to fetch ML models" });
    }
  });

  // Update ML model accuracy
  app.patch("/api/ml-model/:id/accuracy", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid ML model ID" });
      }
      
      const { accuracy } = req.body;
      if (typeof accuracy !== 'number' || accuracy < 0 || accuracy > 100) {
        return res.status(400).json({ message: "Invalid accuracy value (0-100)" });
      }
      
      const updatedModel = await storage.updateMlModelAccuracy(id, accuracy);
      if (!updatedModel) {
        return res.status(404).json({ message: "ML model not found" });
      }
      
      return res.json(updatedModel);
    } catch (error) {
      console.error("Error updating ML model accuracy:", error);
      return res.status(500).json({ message: "Failed to update ML model accuracy" });
    }
  });
}