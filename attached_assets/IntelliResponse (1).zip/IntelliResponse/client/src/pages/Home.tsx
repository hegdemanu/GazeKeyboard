import { useState, useEffect } from 'react';
import GazeKeyboard from '@/components/GazeKeyboard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

export default function Home() {
  const [isCalibrated, setIsCalibrated] = useState(false);
  const [inputText, setInputText] = useState('');
  const [showCalibration, setShowCalibration] = useState(true);
  const [showInstructions, setShowInstructions] = useState(true);

  // Start calibration when the page loads
  useEffect(() => {
    // Check if WebGazer is available
    if (typeof window !== 'undefined' && 'webgazer' in window) {
      // Setup callback for when calibration is complete
      const handleCalibrationComplete = () => {
        setIsCalibrated(true);
        setShowCalibration(false);
      };

      // In a real app, you'd want to check when calibration is actually complete
      // For demo purposes, we're using a timeout
      const calibrationTimeout = setTimeout(handleCalibrationComplete, 10000);

      return () => {
        // Clean up
        clearTimeout(calibrationTimeout);
        if ('webgazer' in window) {
          (window as any).webgazer.end();
        }
      };
    }
  }, []);

  const handleTextUpdate = (text: string) => {
    setInputText(text);
  };

  const toggleInstructions = () => {
    setShowInstructions(!showInstructions);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-900 text-white p-4">
      <header className="mb-6">
        <h1 className="text-3xl font-bold text-center text-primary">Eye-Gaze Keyboard</h1>
      </header>

      <div className="mb-6 flex justify-between items-center">
        <div className="flex items-center space-x-2">
          <Switch 
            id="show-instructions" 
            checked={showInstructions} 
            onCheckedChange={toggleInstructions} 
          />
          <Label htmlFor="show-instructions">Show Instructions</Label>
        </div>
        <div className="flex items-center space-x-2">
          <div className={`h-3 w-3 rounded-full ${isCalibrated ? 'bg-green-500' : 'bg-red-500'}`}></div>
          <span>{isCalibrated ? 'Calibrated' : 'Not Calibrated'}</span>
        </div>
      </div>

      {showInstructions && (
        <Card className="mb-6 bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>How to Use the Eye-Gaze Keyboard</CardTitle>
          </CardHeader>
          <CardContent>
            <ol className="list-decimal pl-4 space-y-2">
              <li>Look at the screen and make sure your face is visible to the camera</li>
              <li>When calibration is complete, you'll see the keyboard highlighted in green</li>
              <li>Look at a letter for 800ms (0.8 seconds) to select it</li>
              <li>A progress ring will show how long you've been looking at a letter</li>
              <li>Word suggestions will appear in the outer ring as you type</li>
              <li>Look at a suggested word to complete your text</li>
            </ol>
          </CardContent>
        </Card>
      )}

      {showCalibration && (
        <Card className="mb-6 bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Calibration in Progress</CardTitle>
          </CardHeader>
          <CardContent>
            <p>Please look at different areas of the screen for a few seconds.</p>
            <p>Calibration will complete automatically.</p>
          </CardContent>
        </Card>
      )}

      <div className="flex-1 flex flex-col items-center justify-center">
        <Card className="w-full max-w-xl bg-gray-800 border-gray-700 mb-6">
          <CardContent className="pt-6">
            <textarea
              className="w-full h-24 p-3 rounded bg-gray-700 text-white border-none resize-none focus:ring-2 focus:ring-primary"
              value={inputText}
              readOnly
              placeholder="Text will appear here as you gaze at letters..."
            />
          </CardContent>
        </Card>

        <div className="w-full max-w-4xl relative">
          <GazeKeyboard onTextUpdate={handleTextUpdate} />
        </div>
      </div>
    </div>
  );
}
