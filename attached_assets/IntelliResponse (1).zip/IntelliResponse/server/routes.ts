import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertInputHistorySchema, 
  insertDictionarySchema, 
  insertDictionaryWordSchema,
  insertUserSchema
} from "@shared/schema";
import { z } from "zod";
import { registerFreelancerRoutes } from "./freelancer-routes";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for the application
  
  // User management
  app.post("/api/user/register", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(validatedData.username);
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const user = await storage.createUser(validatedData);
      
      // Don't return the password in the response
      const { password, ...userWithoutPassword } = user;
      return res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid user data", errors: error.errors });
      }
      console.error("Error creating user:", error);
      return res.status(500).json({ message: "Failed to create user" });
    }
  });
  
  app.post("/api/user/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        return res.status(400).json({ message: "Username and password are required" });
      }
      
      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }
      
      // Don't return the password in the response
      const { password: _, ...userWithoutPassword } = user;
      return res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error during login:", error);
      return res.status(500).json({ message: "Failed to login" });
    }
  });
  
  app.get("/api/user/:id", async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't return the password in the response
      const { password, ...userWithoutPassword } = user;
      return res.json(userWithoutPassword);
    } catch (error) {
      console.error("Error fetching user:", error);
      return res.status(500).json({ message: "Failed to fetch user" });
    }
  });
  
  // Get default dictionary words for word prediction
  app.get("/api/dictionary/default/words", async (req, res) => {
    try {
      const defaultDictionary = await storage.getDefaultDictionary();
      if (!defaultDictionary) {
        return res.status(404).json({ message: "Default dictionary not found" });
      }
      
      const words = await storage.getWordsByDictionaryId(defaultDictionary.id);
      return res.json(words.map(word => ({ word: word.word, weight: word.weight })));
    } catch (error) {
      console.error("Error fetching dictionary words:", error);
      return res.status(500).json({ message: "Failed to fetch dictionary words" });
    }
  });

  // Save input history (for analytics and improving predictions)
  app.post("/api/input/history", async (req, res) => {
    try {
      const validatedData = insertInputHistorySchema.parse(req.body);
      const inputHistory = await storage.saveInputHistory(validatedData);
      return res.status(201).json(inputHistory);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid input data", errors: error.errors });
      }
      return res.status(500).json({ message: "Failed to save input history" });
    }
  });

  // Create a new custom dictionary
  app.post("/api/dictionary", async (req, res) => {
    try {
      const validatedData = insertDictionarySchema.parse(req.body);
      const dictionary = await storage.createDictionary(validatedData);
      return res.status(201).json(dictionary);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid dictionary data", errors: error.errors });
      }
      return res.status(500).json({ message: "Failed to create dictionary" });
    }
  });

  // Add a word to a dictionary
  app.post("/api/dictionary/word", async (req, res) => {
    try {
      const validatedData = insertDictionaryWordSchema.parse(req.body);
      const word = await storage.addWordToDictionary(validatedData);
      return res.status(201).json(word);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid word data", errors: error.errors });
      }
      return res.status(500).json({ message: "Failed to add word to dictionary" });
    }
  });

  // Get user dictionaries
  app.get("/api/user/:userId/dictionaries", async (req, res) => {
    try {
      const userId = parseInt(req.params.userId);
      if (isNaN(userId)) {
        return res.status(400).json({ message: "Invalid user ID" });
      }
      
      const dictionaries = await storage.getDictionariesByUserId(userId);
      return res.json(dictionaries);
    } catch (error) {
      return res.status(500).json({ message: "Failed to fetch user dictionaries" });
    }
  });

  // Register freelancer-specific routes
  await registerFreelancerRoutes(app);

  const httpServer = createServer(app);
  return httpServer;
}
