import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CustomerInquiries } from '@/components/freelancer/CustomerInquiries';
import { SavedResponses } from '@/components/freelancer/SavedResponses';
import { ResponseStatistics } from '@/components/freelancer/ResponseStatistics';
import { ContextualTags } from '@/components/freelancer/ContextualTags';

export default function FreelancerDashboard() {
  const [freelancerId, setFreelancerId] = useState<number | null>(null);
  const [activeTab, setActiveTab] = useState('inquiries');

  // Get user info from localStorage on component mount
  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (userData) {
      try {
        const user = JSON.parse(userData);
        if (user.id && user.isFreelancer) {
          setFreelancerId(user.id);
        }
      } catch (error) {
        console.error('Failed to parse user data', error);
      }
    }
  }, []);

  // Fetch freelancer data
  const { data: userStats, isLoading } = useQuery({
    queryKey: ['/api/freelancer/stats', freelancerId],
    queryFn: async () => {
      if (!freelancerId) return null;
      const res = await fetch(`/api/freelancer/${freelancerId}/stats`);
      if (!res.ok) throw new Error('Failed to fetch freelancer stats');
      return res.json();
    },
    enabled: !!freelancerId,
  });

  if (!freelancerId) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-gray-900 text-white p-4">
        <Card className="w-full max-w-md bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Freelancer Account Required</CardTitle>
            <CardDescription>
              You need to login as a freelancer to access this dashboard.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              className="w-full"
              onClick={() => window.location.href = '/'}
            >
              Return to Home
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-gray-900 text-white p-4">
      <header className="mb-6">
        <h1 className="text-3xl font-bold text-primary">Freelancer Dashboard</h1>
        <p className="text-gray-400">Manage your automated customer inquiry responses</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Total Inquiries</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-primary">
              {isLoading ? '...' : userStats?.totalInquiries || 0}
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Saved Responses</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-primary">
              {isLoading ? '...' : userStats?.totalResponses || 0}
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Effectiveness</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-primary">
              {isLoading ? '...' : `${userStats?.averageEffectiveness || 0}%`}
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="inquiries" value={activeTab} onValueChange={setActiveTab} className="flex-1">
        <TabsList className="mb-4 bg-gray-800">
          <TabsTrigger value="inquiries">Customer Inquiries</TabsTrigger>
          <TabsTrigger value="responses">Saved Responses</TabsTrigger>
          <TabsTrigger value="stats">Response Stats</TabsTrigger>
          <TabsTrigger value="tags">Contextual Tags</TabsTrigger>
        </TabsList>
        
        <TabsContent value="inquiries" className="flex-1">
          <CustomerInquiries freelancerId={freelancerId} />
        </TabsContent>
        
        <TabsContent value="responses" className="flex-1">
          <SavedResponses freelancerId={freelancerId} />
        </TabsContent>
        
        <TabsContent value="stats" className="flex-1">
          <ResponseStatistics freelancerId={freelancerId} />
        </TabsContent>
        
        <TabsContent value="tags" className="flex-1">
          <ContextualTags freelancerId={freelancerId} />
        </TabsContent>
      </Tabs>
    </div>
  );
}