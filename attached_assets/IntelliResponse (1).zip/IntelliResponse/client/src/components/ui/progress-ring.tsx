interface ProgressRingProps {
  progress: number;
  size: number;
  strokeWidth: number;
  stroke?: string;
  fill?: string;
}

export function ProgressRing({ 
  progress, 
  size, 
  strokeWidth, 
  stroke = "rgb(59, 130, 246)", 
  fill = "transparent" 
}: ProgressRingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = radius * 2 * Math.PI;
  const strokeDashoffset = circumference * (1 - progress / 100);

  return (
    <svg 
      className="progress-ring absolute inset-0 -z-10"
      width={size} 
      height={size}
    >
      <circle
        className="progress-ring__circle"
        stroke={stroke}
        strokeWidth={strokeWidth}
        strokeDasharray={`${circumference} ${circumference}`}
        style={{ strokeDashoffset }}
        fill={fill}
        r={radius}
        cx={size / 2}
        cy={size / 2}
        strokeLinecap="round"
      />
      <style jsx>{`
        .progress-ring__circle {
          transition: stroke-dashoffset 0.1s;
          transform: rotate(-90deg);
          transform-origin: 50% 50%;
        }
      `}</style>
    </svg>
  );
}
