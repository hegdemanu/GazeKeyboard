import { 
  users, type User, type InsertUser,
  inputHistory, type InputHistory, type InsertInputHistory,
  dictionaries, type Dictionary, type InsertDictionary,
  dictionaryWords, type DictionaryWord, type InsertDictionaryWord,
  customerInquiries, type CustomerInquiry, type InsertCustomerInquiry,
  savedResponses, type SavedResponse, type InsertSavedResponse,
  responseFeedback, type ResponseFeedback, type InsertResponseFeedback,
  contextualTags, type ContextualTag, type InsertContextualTag,
  inquiryTags, type InquiryTag, type InsertInquiryTag,
  mlModels, type MlModel, type InsertMlModel
} from "@shared/schema";

// Storage interface with all required CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Input history operations
  saveInputHistory(inputHistory: InsertInputHistory): Promise<InputHistory>;
  getInputHistoryByUserId(userId: number): Promise<InputHistory[]>;
  
  // Dictionary operations
  createDictionary(dictionary: InsertDictionary): Promise<Dictionary>;
  getDictionaryById(id: number): Promise<Dictionary | undefined>;
  getDictionariesByUserId(userId: number): Promise<Dictionary[]>;
  getDefaultDictionary(): Promise<Dictionary | undefined>;
  
  // Dictionary words operations
  addWordToDictionary(word: InsertDictionaryWord): Promise<DictionaryWord>;
  getWordsByDictionaryId(dictionaryId: number): Promise<DictionaryWord[]>;
  updateWordWeight(id: number, weight: number): Promise<DictionaryWord | undefined>;

  // Customer inquiries operations
  createCustomerInquiry(inquiry: InsertCustomerInquiry): Promise<CustomerInquiry>;
  getCustomerInquiryById(id: number): Promise<CustomerInquiry | undefined>;
  getCustomerInquiriesByFreelancerId(freelancerId: number): Promise<CustomerInquiry[]>;
  updateCustomerInquiryFrequency(id: number, frequency: number): Promise<CustomerInquiry | undefined>;
  getCustomerInquiriesByCategory(freelancerId: number, category: string): Promise<CustomerInquiry[]>;
  
  // Saved responses operations
  createSavedResponse(response: InsertSavedResponse): Promise<SavedResponse>;
  getSavedResponseById(id: number): Promise<SavedResponse | undefined>;
  getSavedResponsesByFreelancerId(freelancerId: number): Promise<SavedResponse[]>;
  getSavedResponsesByInquiryId(inquiryId: number): Promise<SavedResponse[]>;
  getDefaultSavedResponseForInquiry(inquiryId: number): Promise<SavedResponse | undefined>;
  updateSavedResponseEffectiveness(id: number, effectiveness: number): Promise<SavedResponse | undefined>;
  
  // Response feedback operations
  createResponseFeedback(feedback: InsertResponseFeedback): Promise<ResponseFeedback>;
  getResponseFeedbackByResponseId(responseId: number): Promise<ResponseFeedback[]>;
  
  // Contextual tags operations
  createContextualTag(tag: InsertContextualTag): Promise<ContextualTag>;
  getContextualTagById(id: number): Promise<ContextualTag | undefined>;
  getContextualTagsByFreelancerId(freelancerId: number): Promise<ContextualTag[]>;
  
  // Inquiry tags operations
  createInquiryTag(inquiryTag: InsertInquiryTag): Promise<InquiryTag>;
  getInquiryTagsByInquiryId(inquiryId: number): Promise<InquiryTag[]>;
  getInquiryTagsByTagId(tagId: number): Promise<InquiryTag[]>;
  
  // ML models operations
  createMlModel(model: InsertMlModel): Promise<MlModel>;
  getMlModelById(id: number): Promise<MlModel | undefined>;
  getMlModelsByFreelancerId(freelancerId: number): Promise<MlModel[]>;
  updateMlModelAccuracy(id: number, accuracy: number): Promise<MlModel | undefined>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private userStore: Map<number, User>;
  private inputHistoryStore: Map<number, InputHistory>;
  private dictionaryStore: Map<number, Dictionary>;
  private dictionaryWordStore: Map<number, DictionaryWord>;
  private customerInquiryStore: Map<number, CustomerInquiry>;
  private savedResponseStore: Map<number, SavedResponse>;
  private responseFeedbackStore: Map<number, ResponseFeedback>;
  private contextualTagStore: Map<number, ContextualTag>;
  private inquiryTagStore: Map<number, InquiryTag>;
  private mlModelStore: Map<number, MlModel>;
  
  private userIdCounter: number;
  private inputHistoryIdCounter: number;
  private dictionaryIdCounter: number;
  private dictionaryWordIdCounter: number;
  private customerInquiryIdCounter: number;
  private savedResponseIdCounter: number;
  private responseFeedbackIdCounter: number;
  private contextualTagIdCounter: number;
  private inquiryTagIdCounter: number;
  private mlModelIdCounter: number;

  constructor() {
    this.userStore = new Map();
    this.inputHistoryStore = new Map();
    this.dictionaryStore = new Map();
    this.dictionaryWordStore = new Map();
    this.customerInquiryStore = new Map();
    this.savedResponseStore = new Map();
    this.responseFeedbackStore = new Map();
    this.contextualTagStore = new Map();
    this.inquiryTagStore = new Map();
    this.mlModelStore = new Map();
    
    this.userIdCounter = 1;
    this.inputHistoryIdCounter = 1;
    this.dictionaryIdCounter = 1;
    this.dictionaryWordIdCounter = 1;
    this.customerInquiryIdCounter = 1;
    this.savedResponseIdCounter = 1;
    this.responseFeedbackIdCounter = 1;
    this.contextualTagIdCounter = 1;
    this.inquiryTagIdCounter = 1;
    this.mlModelIdCounter = 1;
    
    // Initialize with default dictionary
    this.initializeDefaultDictionary();
  }

  // Initialize default dictionary with common words
  private async initializeDefaultDictionary() {
    const defaultDictionary = await this.createDictionary({
      userId: 0, // System user
      name: "Default Dictionary",
      isDefault: true
    });
    
    const defaultWords = [
      'apple', 'angle', 'able', 'banana', 'band', 'cat', 'cater', 'dog', 'delta',
      'elephant', 'energy', 'fish', 'gaze', 'glare', 'hello', 'hi', 'input',
      'javascript', 'key', 'keyboard', 'number', 'output', 'predict', 'random',
      'select', 'text', 'user', 'zoom'
    ];
    
    for (const word of defaultWords) {
      await this.addWordToDictionary({
        dictionaryId: defaultDictionary.id,
        word,
        weight: 1
      });
    }
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.userStore.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.userStore.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date()
    };
    this.userStore.set(id, user);
    return user;
  }

  // Input history methods
  async saveInputHistory(insertInputHistory: InsertInputHistory): Promise<InputHistory> {
    const id = this.inputHistoryIdCounter++;
    const inputHistoryEntry: InputHistory = { 
      userId: insertInputHistory.userId || null, 
      inputText: insertInputHistory.inputText,
      timestamp: insertInputHistory.timestamp,
      id 
    };
    this.inputHistoryStore.set(id, inputHistoryEntry);
    return inputHistoryEntry;
  }

  async getInputHistoryByUserId(userId: number): Promise<InputHistory[]> {
    return Array.from(this.inputHistoryStore.values())
      .filter(history => history.userId === userId);
  }

  // Dictionary methods
  async createDictionary(insertDictionary: InsertDictionary): Promise<Dictionary> {
    const id = this.dictionaryIdCounter++;
    const dictionary: Dictionary = { 
      name: insertDictionary.name,
      userId: insertDictionary.userId || null,
      isDefault: insertDictionary.isDefault || false,
      id 
    };
    this.dictionaryStore.set(id, dictionary);
    return dictionary;
  }

  async getDictionaryById(id: number): Promise<Dictionary | undefined> {
    return this.dictionaryStore.get(id);
  }

  async getDictionariesByUserId(userId: number): Promise<Dictionary[]> {
    return Array.from(this.dictionaryStore.values())
      .filter(dictionary => dictionary.userId === userId);
  }

  async getDefaultDictionary(): Promise<Dictionary | undefined> {
    return Array.from(this.dictionaryStore.values())
      .find(dictionary => dictionary.isDefault);
  }

  // Dictionary words methods
  async addWordToDictionary(insertWord: InsertDictionaryWord): Promise<DictionaryWord> {
    const id = this.dictionaryWordIdCounter++;
    const word: DictionaryWord = { 
      dictionaryId: insertWord.dictionaryId || null,
      word: insertWord.word,
      weight: insertWord.weight || 1,
      id 
    };
    this.dictionaryWordStore.set(id, word);
    return word;
  }

  async getWordsByDictionaryId(dictionaryId: number): Promise<DictionaryWord[]> {
    return Array.from(this.dictionaryWordStore.values())
      .filter(word => word.dictionaryId === dictionaryId);
  }

  async updateWordWeight(id: number, weight: number): Promise<DictionaryWord | undefined> {
    const word = this.dictionaryWordStore.get(id);
    if (word) {
      const updatedWord = { ...word, weight };
      this.dictionaryWordStore.set(id, updatedWord);
      return updatedWord;
    }
    return undefined;
  }

  // Customer inquiries methods
  async createCustomerInquiry(inquiry: InsertCustomerInquiry): Promise<CustomerInquiry> {
    const id = this.customerInquiryIdCounter++;
    const now = new Date();
    const customerInquiry: CustomerInquiry = { 
      ...inquiry, 
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    this.customerInquiryStore.set(id, customerInquiry);
    return customerInquiry;
  }

  async getCustomerInquiryById(id: number): Promise<CustomerInquiry | undefined> {
    return this.customerInquiryStore.get(id);
  }

  async getCustomerInquiriesByFreelancerId(freelancerId: number): Promise<CustomerInquiry[]> {
    return Array.from(this.customerInquiryStore.values())
      .filter(inquiry => inquiry.freelancerId === freelancerId);
  }

  async updateCustomerInquiryFrequency(id: number, frequency: number): Promise<CustomerInquiry | undefined> {
    const inquiry = this.customerInquiryStore.get(id);
    if (inquiry) {
      const updatedInquiry = { 
        ...inquiry, 
        frequency, 
        updatedAt: new Date() 
      };
      this.customerInquiryStore.set(id, updatedInquiry);
      return updatedInquiry;
    }
    return undefined;
  }

  async getCustomerInquiriesByCategory(freelancerId: number, category: string): Promise<CustomerInquiry[]> {
    return Array.from(this.customerInquiryStore.values())
      .filter(inquiry => inquiry.freelancerId === freelancerId && inquiry.category === category);
  }

  // Saved responses methods
  async createSavedResponse(response: InsertSavedResponse): Promise<SavedResponse> {
    const id = this.savedResponseIdCounter++;
    const now = new Date();
    const savedResponse: SavedResponse = { 
      ...response, 
      id, 
      createdAt: now, 
      updatedAt: now 
    };
    this.savedResponseStore.set(id, savedResponse);
    return savedResponse;
  }

  async getSavedResponseById(id: number): Promise<SavedResponse | undefined> {
    return this.savedResponseStore.get(id);
  }

  async getSavedResponsesByFreelancerId(freelancerId: number): Promise<SavedResponse[]> {
    return Array.from(this.savedResponseStore.values())
      .filter(response => response.freelancerId === freelancerId);
  }

  async getSavedResponsesByInquiryId(inquiryId: number): Promise<SavedResponse[]> {
    return Array.from(this.savedResponseStore.values())
      .filter(response => response.inquiryId === inquiryId);
  }

  async getDefaultSavedResponseForInquiry(inquiryId: number): Promise<SavedResponse | undefined> {
    return Array.from(this.savedResponseStore.values())
      .find(response => response.inquiryId === inquiryId && response.isDefault);
  }

  async updateSavedResponseEffectiveness(id: number, effectiveness: number): Promise<SavedResponse | undefined> {
    const response = this.savedResponseStore.get(id);
    if (response) {
      const updatedResponse = { 
        ...response, 
        effectiveness, 
        updatedAt: new Date() 
      };
      this.savedResponseStore.set(id, updatedResponse);
      return updatedResponse;
    }
    return undefined;
  }

  // Response feedback methods
  async createResponseFeedback(feedback: InsertResponseFeedback): Promise<ResponseFeedback> {
    const id = this.responseFeedbackIdCounter++;
    const responseFeedback: ResponseFeedback = { 
      ...feedback, 
      id, 
      createdAt: new Date() 
    };
    this.responseFeedbackStore.set(id, responseFeedback);
    return responseFeedback;
  }

  async getResponseFeedbackByResponseId(responseId: number): Promise<ResponseFeedback[]> {
    return Array.from(this.responseFeedbackStore.values())
      .filter(feedback => feedback.responseId === responseId);
  }

  // Contextual tags methods
  async createContextualTag(tag: InsertContextualTag): Promise<ContextualTag> {
    const id = this.contextualTagIdCounter++;
    const contextualTag: ContextualTag = { ...tag, id };
    this.contextualTagStore.set(id, contextualTag);
    return contextualTag;
  }

  async getContextualTagById(id: number): Promise<ContextualTag | undefined> {
    return this.contextualTagStore.get(id);
  }

  async getContextualTagsByFreelancerId(freelancerId: number): Promise<ContextualTag[]> {
    return Array.from(this.contextualTagStore.values())
      .filter(tag => tag.freelancerId === freelancerId);
  }

  // Inquiry tags methods
  async createInquiryTag(inquiryTag: InsertInquiryTag): Promise<InquiryTag> {
    const id = this.inquiryTagIdCounter++;
    const newInquiryTag: InquiryTag = { ...inquiryTag, id };
    this.inquiryTagStore.set(id, newInquiryTag);
    return newInquiryTag;
  }

  async getInquiryTagsByInquiryId(inquiryId: number): Promise<InquiryTag[]> {
    return Array.from(this.inquiryTagStore.values())
      .filter(inquiryTag => inquiryTag.inquiryId === inquiryId);
  }

  async getInquiryTagsByTagId(tagId: number): Promise<InquiryTag[]> {
    return Array.from(this.inquiryTagStore.values())
      .filter(inquiryTag => inquiryTag.tagId === tagId);
  }

  // ML model methods
  async createMlModel(model: InsertMlModel): Promise<MlModel> {
    const id = this.mlModelIdCounter++;
    const mlModel: MlModel = { 
      ...model, 
      id, 
      lastTrained: new Date() 
    };
    this.mlModelStore.set(id, mlModel);
    return mlModel;
  }

  async getMlModelById(id: number): Promise<MlModel | undefined> {
    return this.mlModelStore.get(id);
  }

  async getMlModelsByFreelancerId(freelancerId: number): Promise<MlModel[]> {
    return Array.from(this.mlModelStore.values())
      .filter(model => model.freelancerId === freelancerId);
  }

  async updateMlModelAccuracy(id: number, accuracy: number): Promise<MlModel | undefined> {
    const model = this.mlModelStore.get(id);
    if (model) {
      const updatedModel = { 
        ...model, 
        accuracy, 
        lastTrained: new Date() 
      };
      this.mlModelStore.set(id, updatedModel);
      return updatedModel;
    }
    return undefined;
  }
}

export const storage = new MemStorage();
