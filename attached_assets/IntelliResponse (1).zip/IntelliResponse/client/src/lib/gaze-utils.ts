type GazeData = { x: number; y: number } | null;
type GazeCallback = (data: GazeData) => void;

declare global {
  interface Window {
    webgazer: {
      setGazeListener: (callback: GazeCallback) => any;
      setRegression: (type: string) => any;
      begin: () => any;
      end: () => void;
      showVideo: (show: boolean) => any;
      showFaceOverlay: (show: boolean) => any;
      showPredictionPoints: (show: boolean) => any;
      pause: () => any;
      resume: () => any;
    };
  }
}

/**
 * Initialize the WebGazer eye-tracking system
 * @param callback Function to call with gaze position data
 * @returns Cleanup function to remove event listeners
 */
export function initGazeTracking(callback: GazeCallback) {
  // Make sure WebGazer is loaded
  if (!window.webgazer) {
    console.error("WebGazer.js is not loaded. Please include it in your HTML.");
    return () => {};
  }

  // Configure WebGazer
  window.webgazer
    .setRegression('ridge')  // faster / good-enough algorithm
    .setGazeListener(callback)
    .showVideo(false)        // hide built-in UI components
    .showFaceOverlay(false)
    .showPredictionPoints(false)
    .begin();

  // Handle window visibility for better performance
  const handleVisibilityChange = () => {
    if (document.hidden) {
      window.webgazer.pause();
    } else {
      window.webgazer.resume();
    }
  };

  document.addEventListener("visibilitychange", handleVisibilityChange);

  // Return cleanup function
  return () => {
    document.removeEventListener("visibilitychange", handleVisibilityChange);
    if (window.webgazer) {
      window.webgazer.end();
    }
  };
}

/**
 * Clean up WebGazer resources
 */
export function cleanupGazeTracking() {
  if (window.webgazer) {
    window.webgazer.end();
  }
}
