import { useEffect, useRef, useState } from "react";
import { ProgressRing } from "./ui/progress-ring";
import { initGazeTracking, cleanupGazeTracking } from "@/lib/gaze-utils";

interface GazeKeyboardProps {
  onTextUpdate: (text: string) => void;
}

// Constants
const CENTER = { x: 400, y: 400 };
const DWELL_MS = 800; // gaze hold to "click"
const rings = [
  { items: ['A','E','I','O','U'], radius: 60 },
  { items: [...'BCDFGHJKLMNPQRSTVWXYZ'], radius: 180 },
  { items: ['0','1','2','3','4','5','6','7','8','9'], radius: 300 },
  { items: [], radius: 380 } // word predictions
];

// Mini dictionary for suggestions
const dictionary = [
  'apple','angle','able','banana','band','cat','cater','dog','delta',
  'elephant','energy','fish','gaze','glare','hello','hi','input',
  'javascript','key','keyboard','number','output','predict','random',
  'select','text','user','zoom'
];

const GazeKeyboard: React.FC<GazeKeyboardProps> = ({ onTextUpdate }) => {
  const [output, setOutput] = useState('');
  const [dwellEl, setDwellEl] = useState<HTMLElement | null>(null);
  const [dwellStart, setDwellStart] = useState<number | null>(null);
  const [dwellProgress, setDwellProgress] = useState(0);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const keyboardRef = useRef<HTMLDivElement>(null);
  const rafRef = useRef<number | null>(null);

  // Convert polar coordinates to Cartesian for key positioning
  const polarToXY = (r: number, idx: number, total: number) => {
    const theta = (2 * Math.PI) * (idx / total) - Math.PI / 2;
    return {
      x: CENTER.x + r * Math.cos(theta) - 30,
      y: CENTER.y + r * Math.sin(theta) - 30
    };
  };

  // Create beep sound for selection feedback
  const beep = () => {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.frequency.value = 600; // Hz
    gain.gain.value = 0.12; // volume
    osc.start();
    osc.stop(ctx.currentTime + 0.07);
  };

  // Update word recommendations based on current text
  const updateRecommendations = (text: string) => {
    const prefix = text.toLowerCase();
    const recs = dictionary
      .filter(w => w.startsWith(prefix) && w.length > prefix.length)
      .slice(0, 8);
    setSuggestions(recs);
  };

  // Select a key when dwell time is complete
  const selectKey = (ch: string) => {
    const newOutput = output + ch;
    setOutput(newOutput);
    onTextUpdate(newOutput);
    beep();
    updateRecommendations(newOutput);
  };

  // Update dwell progress animation
  const updateDwellAnimation = (timestamp: number) => {
    if (dwellStart === null || dwellEl === null) {
      rafRef.current = null;
      return;
    }

    const elapsed = timestamp - dwellStart;
    const progress = Math.min(1, elapsed / DWELL_MS);
    setDwellProgress(progress);

    if (elapsed >= DWELL_MS) {
      // Selection complete
      selectKey(dwellEl.textContent || '');
      // Prevent immediate re-selection
      setDwellStart(performance.now() + 1e6);
    } else {
      // Continue the animation
      rafRef.current = requestAnimationFrame(updateDwellAnimation);
    }
  };

  // Setup gaze tracking
  useEffect(() => {
    if (!keyboardRef.current) return;

    const handleGazeData = (data: { x: number, y: number } | null) => {
      if (!data) return;

      const x = data.x, y = data.y;
      const elt = document.elementFromPoint(x, y) as HTMLElement;

      if (elt && elt.classList.contains('key')) {
        // Entered a new key
        if (elt !== dwellEl) {
          setDwellEl(elt);
          setDwellStart(performance.now());
          
          // Cancel any existing animation frame
          if (rafRef.current) {
            cancelAnimationFrame(rafRef.current);
          }
          // Start new animation
          rafRef.current = requestAnimationFrame(updateDwellAnimation);
          
          // Remove selected class from all keys
          document.querySelectorAll('.key').forEach(k => 
            k.classList.remove('selected'));
        }
        // Add selected class to current key
        elt.classList.add('selected');
      } else {
        // Gaze in empty space
        setDwellEl(null);
        setDwellStart(null);
        setDwellProgress(0);
        if (rafRef.current) {
          cancelAnimationFrame(rafRef.current);
          rafRef.current = null;
        }
        document.querySelectorAll('.key').forEach(k => 
          k.classList.remove('selected'));
      }
    };

    // Initialize WebGazer
    const cleanup = initGazeTracking(handleGazeData);

    return () => {
      cleanup();
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, [dwellEl]);

  // Update recommendations when output changes
  useEffect(() => {
    updateRecommendations(output);
  }, [output]);

  return (
    <div 
      ref={keyboardRef} 
      className="relative w-full h-[800px] bg-gray-900 rounded-lg overflow-hidden"
      style={{ margin: '0 auto' }}
    >
      {/* Render keys for all rings */}
      {rings.slice(0, 3).map((ring, ringIndex) => (
        ring.items.map((char, i) => {
          const { x, y } = polarToXY(ring.radius, i, ring.items.length);
          return (
            <div
              key={`${ringIndex}-${i}`}
              className={`key ring${ringIndex} absolute w-[60px] h-[60px] flex items-center justify-center bg-gray-800 text-white text-xl font-bold rounded-full border-2 border-gray-700 transition-all duration-200 hover:bg-gray-700`}
              style={{ 
                left: `${x}px`, 
                top: `${y}px`,
              }}
            >
              {char}
              {dwellEl?.textContent === char && (
                <ProgressRing 
                  progress={dwellProgress * 100} 
                  size={76} 
                  strokeWidth={4} 
                />
              )}
            </div>
          );
        })
      ))}

      {/* Render suggestion keys */}
      {suggestions.map((word, i) => {
        const { x, y } = polarToXY(rings[3].radius, i, suggestions.length);
        return (
          <div
            key={`suggestion-${i}`}
            className={`key ring3 absolute w-[120px] h-[60px] flex items-center justify-center bg-blue-800 text-white text-lg font-bold rounded-full border-2 border-blue-700 transition-all duration-300 scale-100 opacity-100 hover:bg-blue-700`}
            style={{ 
              left: `${x}px`, 
              top: `${y}px`,
              transform: 'translate(-30px, -30px)',
              animation: 'fadeIn 0.3s ease-in-out'
            }}
          >
            {word}
            {dwellEl?.textContent === word && (
              <ProgressRing 
                progress={dwellProgress * 100} 
                size={96} 
                strokeWidth={4} 
              />
            )}
          </div>
        );
      })}

      <style jsx>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.9) translate(-30px, -30px); }
          to { opacity: 1; transform: scale(1) translate(-30px, -30px); }
        }
        
        .key.selected {
          background-color: rgb(59, 130, 246);
          border-color: rgb(96, 165, 250);
          transform: scale(1.05);
        }
      `}</style>
    </div>
  );
};

export default GazeKeyboard;
